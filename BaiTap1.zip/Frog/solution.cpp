#include <iostream>
#include <math.h>
using namespace std;
int main()
{
    int a, b, x;
    cin >> a >> b >> x;
    int y = ceil(x * 1.0 / 2);
    if (x % 2 == 0)
        cout << y * (a - b);
    else
        cout << y * a - b * (y - 1);
    return 0;
}