#include <iostream>
using namespace std;
int main()
{
    int c1, c2, c3, c4, c5;
    cin >> c1 >> c2 >> c3 >> c4 >> c5;
    int total_coins = c1 + c2 + c3 + c4 + c5;
    if (total_coins % 5 == 0 && total_coins > 0)
        cout << total_coins / 5;
    else
        cout << -1;

    return 0;
}
