#include <iostream>
using namespace std;
int main()
{
    int n;
    cin >> n;
    int x = n / 28;
    int sum = x;
    while (x >= 3)
    {
        sum += x / 3;
        x /= 3;
    }
    cout << sum;
    return 0;
}
