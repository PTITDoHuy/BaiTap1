# Đồng xu
- Bạn có số lượng xu không giới hạn với các giá trị 1,2,3,……n (từ 1 tới n). Bạn muốn chọn một số bộ tiền có tổng giá trị S. Nó được phép có nhiều đồng tiền có cùng giá trị trong tập hợp. Số lượng đồng xu tối thiểu cần thiết để có được tổng S là bao nhiêu?

### Input
- Dòng duy nhất của đầu vào chứa hai số nguyên n và S

### Điều kiện
- 1<=n<=10^6^; 1<=S<=10^9^

### Output
- In chính xác một số nguyên - số lượng xu tối thiểu cần thiết để có được tổng S.

### Ví dụ
- Input: 5 11
- Output: 3